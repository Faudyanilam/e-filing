<?php 
$con = mysqli_connect('localhost', 'root', '', 'database_pbl');
?>